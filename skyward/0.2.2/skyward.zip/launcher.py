#!/usr/bin/python3
import os
import signal
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
import gi
gi.require_version("Gtk","3.0")
gi.require_version("GdkPixbuf","2.0")
from gi.repository import Gtk, GLib, GdkPixbuf
from wifi_panel import panel

ROOT=Path(__file__).resolve().parent
runtime=tempfile.TemporaryDirectory(prefix="skyward-")
preview=Path(runtime.name)/"preview.pgm"
window=Gtk.Window(title="SKYWARD")
window.set_default_size(800,480)
window.set_decorated(False)
window.fullscreen()
css=Gtk.CssProvider()
css.load_from_data(b"""
window {background:#07130f;} label {color:#c1d6c6;}
button {background:#10271d;color:#cbe7ce;border:1px solid #355444;border-radius:3px;padding:5px;box-shadow:none;text-shadow:none;}
button:active,#selected {background:#284d35;border-color:#92d19b;}
#rail {background:#0a1912;border-left:1px solid #48694e;padding:6px;}
#freq {color:#b7f6b4;font:bold 18px monospace;}
#tag {color:#91b69b;font:11px monospace;}
#screen {background:black;} progressbar trough {background:#1e3227;min-height:5px;} progressbar progress {background:#87c68d;min-height:5px;}
""")
Gtk.StyleContext.add_provider_for_screen(window.get_screen(),css,600)
pages=Gtk.Stack()
# Hidden settings and Wi-Fi pages must not set the size of the receiving screen.
pages.set_hhomogeneous(False)
pages.set_vhomogeneous(False)
window.add(pages)
def box(vertical=True,spacing=4):
    return Gtk.Box(orientation=Gtk.Orientation.VERTICAL if vertical else Gtk.Orientation.HORIZONTAL,spacing=spacing)
def label(parent,text,name=None):
    item=Gtk.Label(label=text)
    if name:item.set_name(name)
    parent.pack_start(item,False,False,0)
    return item
def button(parent,text,fn):
    item=Gtk.Button(label=text)
    item.connect("clicked",lambda *_:fn())
    parent.pack_start(item,False,False,0)
    return item
splash=box()
splash.set_valign(Gtk.Align.CENTER)
# Tint the original wordmark and emblem together at display time.
import base64
art=(ROOT/"dred-tech.jpeg").read_bytes()
src=GdkPixbuf.Pixbuf.new_from_file(str(ROOT/"dred-tech.jpeg"))
sw,sh=src.get_width(),src.get_height()
encoded=base64.b64encode(art).decode("ascii")
svg=f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="290" height="350" viewBox="0 0 {sw} {sh}">
<defs><filter id="green" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="0 .52 0 0 .025  0 .88 0 0 .065  0 .61 0 0 .045  0 0 0 1 0"/></filter></defs>
<image width="{sw}" height="{sh}" filter="url(#green)" xlink:href="data:image/jpeg;base64,{encoded}"/></svg>'''
loader=GdkPixbuf.PixbufLoader.new_with_type("svg")
loader.write(svg.encode())
loader.close()
logo=loader.get_pixbuf()
splash.add(Gtk.Image.new_from_pixbuf(logo))
label(splash,"S K Y W A R D","freq")
pages.add_named(splash,"boot")
main=box(False,0)
pages.add_named(main,"main")
screen=Gtk.EventBox()
screen.set_name("screen")
picture=Gtk.Image()
screen.add(picture)
main.pack_start(screen,True,True,0)
rail=box()
rail.set_name("rail")
rail.set_size_request(152,-1)
main.pack_end(rail,False,False,0)
label(rail,"S K Y W A R D","tag")
frequency=label(rail,"1000 МГц","freq")
progress=Gtk.ProgressBar()
rail.pack_start(progress,False,False,0)
progress.set_show_text(True)
status=label(rail,"Підготовка","tag")
label(rail,"ЗНАЙДЕНІ ЧАСТОТИ","tag")
scroll=Gtk.ScrolledWindow()
scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC)
sources=box()
scroll.add(sources)
rail.pack_start(scroll,True,True,0)
resume=button(rail,"Продовжити\nсканування",lambda:start_cycle())
resume.set_no_show_all(True)
button(rail,"⚙   Налаштування",lambda:pages.set_visible_child_name("settings"))
settings=box(True,10)
settings.set_size_request(470,-1)
settings.set_halign(Gtk.Align.CENTER)
settings.set_valign(Gtk.Align.CENTER)
settings.set_margin_start(18)
settings.set_margin_end(18)
pages.add_named(settings,"settings")
label(settings,"НАЛАШТУВАННЯ","freq")
def dialog(title):
    win=Gtk.Window(title=title,transient_for=window,modal=True)
    win.set_decorated(False)
    win.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
    win.set_default_size(490,330)
    body=box(True,5)
    body.set_border_width(12)
    win.add(body)
    label(body,title,"freq")
    body.add(Gtk.Separator())
    return win,body

def open_wifi():
    win,body=dialog("Wi-Fi")
    stack=Gtk.Stack()
    body.pack_start(stack,True,True,0)
    show=panel(stack,on_close=win.destroy)
    win.show_all()
    show(None)
    win.present()

def information(title,text):
    win,body=dialog(title)
    label(body,text).set_line_wrap(True)
    button(body,"Назад",win.destroy)
    win.show_all()
    win.present()

button(settings,"Wi-Fi",open_wifi)
VERSION=(ROOT/"VERSION").read_text().strip()
updater=Path.home()/".local/share/skyward/tools/client.py"
restart_for_update=False
def updates():
    win,body=dialog("Оновлення SKYWARD")
    note=label(body,"Перевірка підписаного релізу…")
    def work(args,done):
        def run():
            try:
                r=subprocess.run([sys.executable,str(updater),*args],capture_output=True,text=True,timeout=180)
                ok=r.returncode==0
                value=r.stdout.strip()
            except (OSError,subprocess.TimeoutExpired):
                ok,value=False,""
            GLib.idle_add(done,ok,value)
        threading.Thread(target=run,daemon=True).start()
    def installed(ok,_):
        global restart_for_update
        if ok:
            restart_for_update=True
            Gtk.main_quit()
        else:note.set_text("Не вдалося встановити оновлення")
    def offer(ok,v):
        if not win.get_visible():return
        if not ok:note.set_text("Не вдалося перевірити реліз")
        elif tuple(map(int,v.split(".")))<=tuple(map(int,VERSION.split("."))):
            note.set_text("Встановлено актуальну версію "+VERSION)
        else:
            note.set_text("Доступна версія "+v)
            def install():
                win.set_sensitive(False)
                note.set_text("Встановлення…")
                def finish(ok,value):
                    win.set_sensitive(True)
                    installed(ok,value)
                work(["install",v,VERSION],finish)
            button(body,"Встановити "+v,install).show()
    button(body,"Назад",win.destroy)
    win.show_all()
    work(["check"],offer)
button(settings,"Оновлення прошивки",updates)
button(settings,"Про пристрій",lambda:information("Про пристрій",f"SKYWARD {VERSION}\nHackRF One · 1000–6000 МГц\n625/50 · 525/60"))
button(settings,"Назад",lambda:pages.set_visible_child_name("main"))

worker=None
watching=None
generation=0
pass_no=1
channels={}
cycle={}
latest=None
stamp=0
def tune(hz):
    frequency.set_text(f"{hz/1e6:g} МГц")

def stop():
    global worker,generation,latest
    generation+=1
    if worker:
        try:os.killpg(worker.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:worker.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(worker.pid,signal.SIGKILL)
            worker.wait()
        worker=None
    latest=None
def spawn(args):
    return subprocess.Popen([sys.executable,*args],cwd=ROOT,stdout=subprocess.PIPE,
        env=dict(os.environ,SKYWARD_PREVIEW=str(preview),OPENBLAS_NUM_THREADS="1"),start_new_session=True)
def rebuild():
    for child in sources.get_children():child.destroy()
    for hz in sorted(channels,key=lambda f:channels[f][0],reverse=True):
        row=button(sources,f"{hz/1e6:g} МГц",lambda f=hz:view(f))
        if hz==watching:row.set_name("selected")
    sources.show_all()
def paint(pix):
    w=max(1,screen.get_allocated_width())
    h=max(1,screen.get_allocated_height())
    h=min(h,w*3//4)
    picture.set_from_pixbuf(pix.scale_simple(max(1,h*4//3),max(1,h),GdkPixbuf.InterpType.BILINEAR))
def view(hz):
    global worker,watching
    stop()
    watching=hz
    mode=channels[hz][1]
    tune(hz)
    status.set_text("● Прямий ефір")
    resume.show()
    rebuild()
    print("view",hz,mode,flush=True)
    worker=spawn(["live_video.py",str(hz),mode])
    proc=worker
    token=generation
    h=240 if mode=="525" else 288
    def read():
        global latest
        with proc.stdout as stream:
            while token==generation:
                frame=stream.read(256*h*3)
                if len(frame)!=256*h*3:break
                if generation==token:latest=(frame,h)
    threading.Thread(target=read,daemon=True).start()
def start_cycle():
    global pass_no,watching
    stop()
    pass_no=1
    cycle.clear()
    watching=None
    resume.hide()
    rebuild()
    scan()
def scan():
    global worker
    progress.set_fraction(0)
    progress.set_text("0 %")
    tune(1000000000)
    status.set_text(f"● Пошук   {pass_no}/2")
    proc=spawn(["search_video.py"])
    worker=proc
    token=generation
    os.set_blocking(proc.stdout.fileno(),False)
    pending=b""
    print("scan",pass_no,flush=True)
    def poll():
        nonlocal pending
        global worker,pass_no
        if token!=generation:
            proc.stdout.close()
            return False
        code=proc.poll()
        while True:
            try:data=os.read(proc.stdout.fileno(),65536)
            except BlockingIOError:break
            if not data:break
            pending+=data
        last=None
        while b"\n" in pending:
            line,pending=pending.split(b"\n",1)
            parts=line.split()
            if parts[:1]==[b"T"]:last=int(parts[1])
            elif parts[:1]==[b"P"]:
                fraction=int(parts[1])/int(parts[2])
                progress.set_fraction(fraction)
                progress.set_text(f"{fraction:.0%}")
            elif parts[:1]==[b"F"]:
                hz=int(parts[1])
                channels[hz]=cycle[hz]=(float(parts[2]),parts[3].decode())
                print("source",hz,flush=True)
                rebuild()
        if last:tune(last)
        if code is None:return True
        proc.stdout.close()
        worker=None
        if code:
            status.set_text("Приймач · повтор…")
            GLib.timeout_add(2000,lambda:scan() if token==generation else False)
        elif pass_no==2 and cycle:view(max(cycle,key=lambda f:cycle[f][0]))
        else:
            pass_no=2 if pass_no==1 else 1
            scan()
        return False
    GLib.timeout_add(55,poll)
def refresh():
    global stamp,latest
    if watching is not None:
        if latest:
            data,h=latest
            latest=None
            paint(GdkPixbuf.Pixbuf.new_from_bytes(GLib.Bytes.new(data),GdkPixbuf.Colorspace.RGB,False,8,256,h,768))
        if worker and worker.poll() is not None:status.set_text("Приймач зупинено")
    elif preview.exists():
        t=preview.stat().st_mtime_ns
        if t!=stamp:
            stamp=t
            paint(GdkPixbuf.Pixbuf.new_from_file(str(preview)))
    return True
def boot():
    pages.set_visible_child_name("main")
    start_cycle()
    if os.environ.get("SKYWARD_READY"):Path(os.environ["SKYWARD_READY"]).touch()
GLib.timeout_add(32,refresh)
window.show_all()
pages.set_visible_child_name("boot")
GLib.timeout_add(1200,boot)
window.connect("destroy",lambda *_:Gtk.main_quit())
try:Gtk.main()
finally:stop()

if restart_for_update:sys.exit(75)
