#include <stdint.h>
#include <math.h>
#include <float.h>
#ifdef VIDEO_525
#define W 1271
#define H 240
#define LINES 525
#define FIELD_SEARCH 265
#define SAMPLES 667344
#define SUBCARRIER 3579545.45
#define ROW(y) ((int)((y)*(20000000.0*1001/15750000)+0.5))
#else
#define W 1280
#define H 288
#define LINES 625
#define FIELD_SEARCH 315
#define SAMPLES (625*W)
#define SUBCARRIER 4433618.75
#define ROW(y) ((y)*W)
#endif
static float phase[65536], cs[W], sn[W], fm[SAMPLES];
static const double omega=2*M_PI*SUBCARRIER/20000000.;
void prepare(void){
    for(int q=0;q<256;q++) for(int i=0;i<256;i++)
        phase[q*256+i]=atan2f((int8_t)q,(int8_t)i);
    for(int i=0;i<W;i++){cs[i]=cos(omega*i);sn[i]=-sin(omega*i);}
}
static uint8_t clip(float x){return x<=0?0:x>=255?255:(uint8_t)x;}
void decode_pal(const uint16_t *iq,uint8_t *rgb){
    float prev=phase[iq[0]], profile[W]={0};
    for(int i=0;i<SAMPLES-1;i++){
        float next=phase[iq[i+1]], d=next-prev;
        if(d>M_PI)d-=2*M_PI;
        if(d<-M_PI)d+=2*M_PI;
        fm[i]=d; prev=next;
    }
    for(int y=0;y<LINES-1;y+=8)for(int x=0;x<W;x++)profile[x]+=fm[ROW(y)+x];
    float sum=0,best=FLT_MAX;
    int sync=0;
    for(int i=0;i<W+59;i++){
        sum+=profile[i%W];
        if(i>=60)sum-=profile[(i-60)%W];
        if(i>=59 && sum<best){best=sum;sync=(i-29)%W;}
    }
    int base=(sync-42+W)%W, first=0;
    best=FLT_MAX;
    float last=0;
    for(int y=0;y<FIELD_SEARCH;y++){
        float level=0;
        for(int x=240;x<800;x+=8)level+=fm[base+ROW(y)+x];
        if(y>=2 && level+last<best){best=level+last;first=y+20;}
        last=level;
    }
    float burst[H],black=0,parity=0;
    for(int y=0;y<H;y++){
        const float *r=fm+base+ROW(first+y);
        float re=0,im=0;
        for(int x=104;x<151;x++){re+=r[x]*cs[x];im+=r[x]*sn[x];}
        burst[y]=atan2f(im,re);
        if(y)parity+=(y%2?1:-1)*sin(burst[y]-burst[y-1]-omega*W);
        for(int x=166;x<185;x++)black+=r[x];
    }
    black/=H*19;
    for(int y=0;y<H;y++){
        const float *r=fm+base+ROW(first+y);
#ifdef VIDEO_525
        int sign=1;
        float angle=M_PI-burst[y];
#else
        int sign=(parity>0?1:-1)*(y%2?-1:1);
        float angle=sign*3*M_PI/4-burst[y];
#endif
        float c=cosf(angle),s=sinf(angle);
        for(int x=205;x<1229;x+=8){
            float l0=(r[x]+r[x+1]+r[x+2]+r[x+3])*.25f;
            float l1=(r[x+4]+r[x+5]+r[x+6]+r[x+7])*.25f;
            float mean=(l0+l1)*.5f,re=0,im=0;
            for(int k=0;k<8;k++){float v=r[x+k]-mean;re+=v*cs[x+k];im+=v*sn[x+k];}
            float u=(c*re-s*im)*57.5f,v=(s*re+c*im)*sign*57.5f;
            for(int k=0;k<2;k++){
                float l=((k?l1:l0)-black)*230;
                *rgb++=clip(l+1.14f*v);*rgb++=clip(l-.395f*u-.581f*v);*rgb++=clip(l+2.032f*u);
            }
        }
    }
}
