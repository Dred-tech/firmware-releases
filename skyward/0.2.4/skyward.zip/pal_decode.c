#include <stdint.h>
#include <math.h>
#include <float.h>
#ifdef VIDEO_525
#define W 1271
#define H 240
#define LINES 525
#define FIELD_SEARCH 265
#define SAMPLES 667344
#define SUBCARRIER 3579545.45
#define ROW(y) ((int)((y)*(20000000.0*1001/15750000)+0.5))
#else
#define W 1280
#define H 288
#define LINES 625
#define FIELD_SEARCH 315
#define SAMPLES (625*W)
#define SUBCARRIER 4433618.75
#define ROW(y) ((y)*W)
#endif
static float phase[65536], cs[W], sn[W], fm[SAMPLES];
static const double omega=2*M_PI*SUBCARRIER/20000000.;
void prepare(void){
    for(int q=0;q<256;q++) for(int i=0;i<256;i++)
        phase[q*256+i]=atan2f((int8_t)q,(int8_t)i);
    for(int i=0;i<W;i++){cs[i]=cos(omega*i);sn[i]=-sin(omega*i);}
}
static uint8_t clip(float x){return x<=0?0:x>=255?255:(uint8_t)x;}
void decode_pal(const uint16_t *iq,uint8_t *rgb){
    float prev=phase[iq[0]], profile[W]={0};
    for(int i=0;i<SAMPLES-1;i++){
        float next=phase[iq[i+1]], d=next-prev;
        if(d>M_PI)d-=2*M_PI;
        if(d<-M_PI)d+=2*M_PI;
        fm[i]=d; prev=next;
    }
    for(int y=0;y<LINES-1;y+=8)for(int x=0;x<W;x++)profile[x]+=fm[ROW(y)+x];
    float sum=0,best=FLT_MAX;
    int sync=0;
    for(int i=0;i<W+59;i++){
        sum+=profile[i%W];
        if(i>=60)sum-=profile[(i-60)%W];
        if(i>=59 && sum<best){best=sum;sync=(i-29)%W;}
    }
    int base=(sync-42+W)%W, first=0;
    best=FLT_MAX;
    float last=0;
    for(int y=0;y<FIELD_SEARCH;y++){
        float level=0;
        for(int x=240;x<800;x+=8)level+=fm[base+ROW(y)+x];
        if(y>=2 && level+last<best){best=level+last;first=y+20;}
        last=level;
    }
    float burst[H],black=0,parity=0;
    for(int y=0;y<H;y++){
        const float *r=fm+base+ROW(first+y);
        float re=0,im=0;
        for(int x=104;x<151;x++){re+=r[x]*cs[x];im+=r[x]*sn[x];}
        burst[y]=atan2f(im,re);
        if(y)parity+=(y%2?1:-1)*sin(burst[y]-burst[y-1]-omega*W);
        for(int x=166;x<185;x++)black+=r[x];
    }
    black/=H*19;
    for(int y=0;y<H;y++){
        const float *r=fm+base+ROW(first+y);
#ifdef VIDEO_525
        int sign=1;
        float angle=M_PI-burst[y];
#else
        int sign=(parity>0?1:-1)*(y%2?-1:1);
        float angle=sign*3*M_PI/4-burst[y];
#endif
        float c=cosf(angle),s=sinf(angle);
        for(int x=205;x<1229;x+=8){
            float l0=(r[x]+r[x+1]+r[x+2]+r[x+3])*.25f;
            float l1=(r[x+4]+r[x+5]+r[x+6]+r[x+7])*.25f;
            float mean=(l0+l1)*.5f,re=0,im=0;
            for(int k=0;k<8;k++){float v=r[x+k]-mean;re+=v*cs[x+k];im+=v*sn[x+k];}
            float u=(c*re-s*im)*57.5f,v=(s*re+c*im)*sign*57.5f;
            for(int k=0;k<2;k++){
                float l=((k?l1:l0)-black)*230;
                *rgb++=clip(l+1.14f*v);*rgb++=clip(l-.395f*u-.581f*v);*rgb++=clip(l+2.032f*u);
            }
        }
    }
}

/* Match the same four segment pulse-depth and vertical recurrence checks
   as the reference Python detector; accumulate all profiles in one pass. */
#include <stdlib.h>
#include <string.h>
static int compare_float(const void *a,const void *b){
    float x=*(const float*)a,y=*(const float*)b;
    return (x>y)-(x<y);
}
static float median(float *values,int n){
    qsort(values,n,sizeof(float),compare_float);
    return (values[(n-1)/2]+values[n/2])*0.5f;
}
static int sync_mode(const float *d,int n,int w,double period,int field){
    int lines=(int)(n/period)-1;
    float sums[4][1280]={{0}},profile[1280],levels[950],tmp[1280];
    int counts[4]={0};
    for(int y=0;y<lines;y++){
        const float *r=d+(int)nearbyint(y*period);
        int seg=y*4/lines;
        counts[seg]++;
        for(int x=0;x<w;x++)sums[seg][x]+=r[x];
    }
    for(int x=0;x<w;x++){
        float total=0;
        for(int j=0;j<4;j++)total+=sums[j][x];
        tmp[x]=profile[x]=total/lines;
    }
    float sum=0,best=FLT_MAX;
    int center=0;
    for(int k=0;k<w+59;k++){
        sum+=profile[k%w];
        if(k>=60)sum-=profile[(k-60)%w];
        if(k>=59 && sum<best){best=sum;center=(k-29)%w;}
    }
    float baseline=median(tmp,w),depth=baseline-best/60;
    if(depth<.15f)return 0;
    for(int j=0;j<4;j++){
        float pulse=0;
        for(int k=-24;k<=24;k++)pulse+=sums[j][(center+w+k)%w];
        memcpy(tmp,sums[j],w*sizeof(float));
        if((median(tmp,w)-pulse/49)/counts[j]<depth*.55f)return 0;
    }
    for(int y=0;y<lines;y++){
        const float *r=d+(int)nearbyint(y*period);
        float level=0;int count=0;
        for(int k=245;k<775;k+=8){level+=r[(center+k)%w];count++;}
        tmp[y]=levels[y]=level/count;
    }
    float cutoff=median(tmp,lines)-depth*.45f;
    for(int y=field;y<lines;y++)
        if(levels[y]<cutoff && (levels[y-field]<cutoff ||
           (y>field && levels[y-field-1]<cutoff)))return 1;
    return 0;
}
int verify_video(const int8_t *raw,double *power,double *offset){
    const int n=1140000;
    raw+=120000;
    double si=0,sq=0,p=0,mean=0;
    for(int k=0;k<n;k++){
        int i=raw[k*2],q=raw[k*2+1];si+=i;sq+=q;p+=i*i+q*q;
    }
    *power=p/n;
    static float lookup[65536],diff[1140000];
    for(int q=0;q<256;q++)for(int i=0;i<256;i++)
        lookup[q*256+i]=atan2f((int8_t)q-sq/n,(int8_t)i-si/n);
    const uint16_t *iq=(const uint16_t*)raw;
    float prev=lookup[iq[0]];
    for(int k=1;k<n;k++){
        float next=lookup[iq[k]],v=next-prev;
        if(v>M_PI)v-=2*M_PI;
        if(v<-M_PI)v+=2*M_PI;
        diff[k-1]=v;mean+=v;prev=next;
    }
    *offset=mean/(n-1)*20000000/(2*M_PI);
    if(sync_mode(diff,n-1,1280,1280.,312))return 625;
    if(sync_mode(diff,n-1,1271,20000000.*1001/15750000,262))return 525;
    return 0;
}
