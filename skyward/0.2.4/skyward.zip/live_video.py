#!/usr/bin/python3
import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import subprocess
import threading
import queue
import sys
import numpy as np


freq = int(sys.argv[1]) if len(sys.argv)>1 else 5695000000
mode=sys.argv[2] if len(sys.argv)>2 else "625"
height,samples,library={"625":(288,800000,"pal_decode.so"),"525":(240,667344,"ntsc_decode.so")}[mode]
import ctypes
from pathlib import Path
decoder=ctypes.CDLL(str(Path(__file__).with_name(library)))
decoder.prepare()
decoder.decode_pal.argtypes=[ctypes.c_char_p,ctypes.c_void_p]
def decode(raw):
    rgb=np.empty((height,256,3),dtype=np.uint8)
    decoder.decode_pal(raw,rgb.ctypes.data)
    return rgb

p=subprocess.Popen(["hackrf_transfer","-r","-","-f",str(freq),"-s","20000000","-b","17500000","-a","0","-p","0","-l","24","-g","24"],stdout=subprocess.PIPE)
# Drain USB independently of decoding. Discard only complete old frames.
frames=queue.Queue(maxsize=1)
def receive():
    while True:
        raw=p.stdout.read(samples*2)
        if len(raw)!=samples*2:
            frames.put(None)
            return
        try:
            frames.put_nowait(raw)
        except queue.Full:
            try: frames.get_nowait()
            except queue.Empty: pass
            frames.put_nowait(raw)
threading.Thread(target=receive,daemon=True).start()
try:
    while True:
        raw=frames.get()
        if raw is None: break
        sys.stdout.buffer.write(decode(raw).tobytes())
        sys.stdout.buffer.flush()
finally:
    if p.poll() is None: p.terminate()
    p.wait()
