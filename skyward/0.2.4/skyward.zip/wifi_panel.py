import os
import subprocess
import tempfile
import threading
from gi.repository import GLib, Gtk

def panel(pages,on_close=None):
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5, margin=8)
    header = Gtk.Box(spacing=6)
    box.pack_start(header, False, False, 0)
    info = Gtk.Label(label="Wi-Fi")
    header.pack_start(info, True, True, 0)
    scroll = Gtk.ScrolledWindow()
    networks = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    scroll.add(networks)
    box.pack_start(scroll, True, True, 0)
    entry = Gtk.Entry(visibility=False, placeholder_text="Пароль Wi-Fi")
    editor = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    editor.pack_start(entry, False, False, 0)
    reveal = Gtk.CheckButton(label="Показати пароль")
    reveal.set_focus_on_click(False)
    reveal.connect("toggled", lambda b: entry.set_visibility(b.get_active()))
    editor.pack_start(reveal, False, False, 0)
    keyboard = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    editor.pack_start(keyboard, True, True, 0)
    box.pack_start(editor, True, True, 0)
    editor.set_no_show_all(True)
    selected = None
    def button(row, title, fn):
        b = Gtk.Button(label=title)
        b.set_focus_on_click(False)
        b.connect("clicked", lambda *_: fn())
        if row is networks:
            b.set_size_request(-1,32)
            b.get_child().set_xalign(0.04)
        row.pack_start(b, row is not networks, row is not networks, 0)
    def keys(mode=0):
        for child in keyboard.get_children():
            child.destroy()
        layouts = [["1234567890","qwertyuiop","asdfghjkl","zxcvbnm"],["1234567890","QWERTYUIOP","ASDFGHJKL","ZXCVBNM"],["!@#$%^&*()","-_=+[]{}",";:'\",.<>","/|\\`~?"]]
        def append(c):
            entry.set_text(entry.get_text()+c)
        for letters in layouts[mode]:
            row = Gtk.Box(homogeneous=True)
            keyboard.pack_start(row, True, True, 0)
            for c in letters:
                button(row,c,lambda c=c: append(c))
        row = Gtk.Box()
        keyboard.pack_start(row, True, True, 0)
        button(row,"abc" if mode else "ABC",lambda: keys(0 if mode else 1))
        button(row,"#+=",lambda: keys(2))
        button(row,"Пробіл",lambda: append(" "))
        button(row,"⌫",lambda: entry.set_text(entry.get_text()[:-1]))
        button(row,"Під’єднатися",connect)
        keyboard.show_all()
    def run(args, secret=None):
        env = dict(os.environ, LC_ALL="C")
        return subprocess.run(["nmcli","--colors","no",*args],input=secret,capture_output=True,text=True,timeout=45,env=env)
    def background(job,done):
        box.set_sensitive(False)
        def work():
            try:
                result=job()
            except (OSError,subprocess.SubprocessError) as error:
                result=(False,"Не вдалося виконати мережеву команду")
            def finish():
                box.set_sensitive(True)
                done(*result)
            GLib.idle_add(finish)
        threading.Thread(target=work,daemon=True).start()
    def choose(name):
        nonlocal selected
        selected=name
        info.set_text(name)
        entry.set_text("")
        scroll.hide()
        keys()
        editor.show()
        reveal.set_active(False)
        reveal.show()
        entry.show()
        entry.grab_focus()
    def refresh():
        editor.hide()
        entry.set_text("")
        scroll.show()
        info.set_text("Пошук мереж…")
        def scan():
            r=run(["-t","--escape","no","-f","SSID","dev","wifi","list","--rescan","yes"])
            return r.returncode==0,r.stdout if not r.returncode else r.stderr
        def loaded(ok,data):
            for child in networks.get_children():
                child.destroy()
            names=list(dict.fromkeys(filter(None,data.splitlines()))) if ok else []
            for name in names:
                button(networks,name,lambda name=name: choose(name))
            networks.show_all()
            info.set_text("Оберіть мережу" if names else ("Мереж не знайдено" if ok else "Не вдалося отримати список мереж"))
        background(scan,loaded)
    def connect():
        password=entry.get_text()
        name=selected
        def activate():
            # Use NetworkManager's password file for a saved SSID. The supplied
            # secret stays out of command arguments and shell history.
            profiles=run(["-g","UUID","con","show"])
            for uuid in profiles.stdout.splitlines():
                profile=run(["-t","--escape","no","-g","802-11-wireless.ssid","con","show",uuid])
                if profile.returncode or profile.stdout.rstrip("\n")!=name:
                    continue
                args=["--wait","30","con","up","uuid",uuid]
                if password:
                    args+=["passwd-file","/dev/stdin"]
                r=run(args,"802-11-wireless-security.psk:"+password+"\n" if password else None)
                break
            else:
                # nmcli asks on a terminal. Use libnm to create a private profile
                # directly when there is no saved connection.
                from gi.repository import NM
                context=GLib.MainContext.new()
                context.push_thread_default()
                client=NM.Client.new(None)
                dev=next((d for d in client.get_devices() if isinstance(d,NM.DeviceWifi)),None)
                if not dev:
                    return False,"Адаптер Wi-Fi недоступний"
                ap=next((a for a in dev.get_access_points() if a.get_ssid() and bytes(a.get_ssid().get_data())==name.encode()),None)
                if not ap:
                    return False,"Мережа зникла. Оновіть список."
                con=NM.SimpleConnection.new()
                setting=NM.SettingConnection.new()
                setting.props.id=name
                setting.props.type="802-11-wireless"
                import getpass
                setting.add_permission("user",getpass.getuser(),None)
                con.add_setting(setting)
                wifi=NM.SettingWireless.new()
                wifi.props.ssid=ap.get_ssid()
                con.add_setting(wifi)
                if password:
                    sec=NM.SettingWirelessSecurity.new()
                    sec.props.key_mgmt="wpa-psk"
                    sec.props.psk=password
                    con.add_setting(sec)
                # Save a new profile with a unique UUID and activate through nmcli.
                from uuid import uuid4
                setting.props.uuid=str(uuid4())
                loop=GLib.MainLoop.new(context,False)
                errors=[]
                def saved(obj,result,*_):
                    try:
                        obj.add_connection_finish(result)
                    except GLib.Error as error:
                        errors.append(str(error))
                    loop.quit()
                client.add_connection_async(con,True,None,saved,None)
                loop.run()
                context.pop_thread_default()
                if errors:
                    return False,"Не вдалося зберегти профіль мережі"
                r=run(["--wait","30","con","up","uuid",setting.props.uuid])
            return r.returncode==0,{3:"Час очікування вичерпано", 4:"Не вдалося активувати з’єднання", 8:"Служба мережі недоступна", 10:"Мережу або профіль не знайдено"}.get(r.returncode,"Не вдалося під’єднатися")
        def safe_activate():
            try:
                return activate()
            except Exception as error:
                return False,"Не вдалося налаштувати з’єднання"
        def finished(ok,detail):
            if ok:
                entry.set_text("")
                editor.hide()
                scroll.show()
            info.set_line_wrap(True)
            info.set_text("Під’єднано" if ok else detail or "Не вдалося під’єднатися")
        info.set_text("Під’єднання…")
        background(safe_activate,finished)
    entry.connect("activate", lambda *_: connect())
    def close():
        entry.set_text("")
        editor.hide()
        if on_close: on_close()
        else: pages.set_visible_child_name("main")
    button(header,"Мережі",refresh)
    button(header,"Назад",close)
    pages.add_named(box,"wifi")
    def open_panel(*_):
        pages.set_visible_child_name("wifi")
        refresh()
    return open_panel
