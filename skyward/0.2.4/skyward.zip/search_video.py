"""Find candidate carriers by sweep and confirm 625/50 line and field sync."""
import subprocess
import sys
from pathlib import Path
import os
recent_file=Path.home()/".cache"/"skyward-video-channels"
import numpy as np

MIN_HZ = 1_000_000_000
MAX_HZ = 6_000_000_000

def sweep():
    flags=["-a","0","-p","0","-l","24","-g","24"]
    bins={}
    cmd=["hackrf_sweep","-N","1","-f","1000:6000","-w","500000",*flags]
    with subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL) as radio:
        for line in radio.stdout:
            cols=line.split(b",")
            if len(cols)<7: continue
            low=float(cols[2]); step=float(cols[4])
            print("T",int(min(MAX_HZ,max(MIN_HZ,low))),flush=True)
            for i,val in enumerate(cols[6:]):
                k=int((low+(i+.5)*step)/500000)
                bins[k]=max(bins.get(k,-150),float(val))
        if radio.wait(): raise RuntimeError("sweep failed")
    if not bins: raise ValueError("empty sweep")
    keys=np.arange(min(bins),max(bins)+1)
    db=np.array([bins.get(k,-100) for k in keys])
    smooth=np.convolve(db,np.ones(9)/9,"same")
    smooth[:12]=smooth[-12:]=-150
    # Recheck known working channels, then reserve candidates in every band.
    try:
        recent=[int(v) for v in recent_file.read_text().split() if v.isdecimal() and MIN_HZ<=int(v)<=MAX_HZ]
    except OSError:
        recent=[]
    peaks=list(dict.fromkeys(recent[:12]+[5865000000,1280000000,5695000000]))
    priority=len(peaks)
    strength={}
    for low,high in ((1000,1500),(1500,2500),(2500,4000),(4000,5000),(5000,6000)):
        band=np.flatnonzero((keys*0.5>=low)&(keys*0.5<high))
        threshold=np.median(db[band])+2
        count=0
        for i in band[np.argsort(smooth[band])[::-1]]:
            if smooth[i]<threshold or count==8: break
            hz=int(keys[i])*500000
            if all(abs(hz-f)>8000000 for f in peaks):
                peaks.append(hz)
                strength[hz]=smooth[i]-threshold
                count+=1
    return peaks[:priority]+sorted(peaks[priority:],key=strength.get,reverse=True)

import ctypes
verify_native=ctypes.CDLL(str(Path(__file__).with_name("pal_decode.so"))).verify_video
verify_native.argtypes=[ctypes.c_char_p,ctypes.POINTER(ctypes.c_double),ctypes.POINTER(ctypes.c_double)]
receiver=None

def verify(hz):
    if not MIN_HZ <= hz <= MAX_HZ:
        return
    print("T",hz,flush=True)
    raw=receiver.capture(hz) if receiver else subprocess.run(["hackrf_transfer","-r","-","-f",str(hz),"-s","20000000","-b","17500000","-n","1200000","-a","0","-p","0","-l","24","-g","24"],capture_output=True,timeout=5,check=True).stdout
    if len(raw)!=2400000: return
    if os.environ.get("SKYWARD_PREVIEW"):
        preview=Path(os.environ["SKYWARD_PREVIEW"])
        preview_iq=np.frombuffer(raw,np.int8,count=(144*1280+1)*2,offset=120000).astype('f').view('F')
        d=np.angle(preview_iq[1:]*preview_iq[:-1].conj())
        gray=d.reshape(144,256,5).mean(2)
        lo,hi=np.percentile(gray,[2,98])
        gray=np.clip((gray-lo)*255/max(.01,hi-lo),0,255).astype("uint8")
        tmp=preview.with_suffix(".part")
        tmp.write_bytes(b"P5\n256 144\n255\n"+gray.tobytes())
        tmp.replace(preview)
    power,offset=ctypes.c_double(),ctypes.c_double()
    mode=verify_native(raw,ctypes.byref(power),ctypes.byref(offset))
    if mode:return power.value,offset.value,str(mode)

if __name__=="__main__":
    candidates=sweep()
    from radio_scan import Receiver
    import atexit
    receiver=Receiver()
    atexit.register(receiver.close)
    total=len(candidates)+1
    print("P",1,total,flush=True)
    for index,candidate in enumerate(candidates):
        for shift in (0,-3000000,3000000):
            tuned=candidate+shift
            if not MIN_HZ<=tuned<=MAX_HZ: continue
            result=verify(tuned)
            if result:
                power,offset,mode=result
                freq=round((tuned+offset)/1000000)*1000000
                confirmed=verify(freq) if MIN_HZ<=freq<=MAX_HZ else None
                if not confirmed or confirmed[2]!=mode:
                    freq=tuned
                    confirmed=verify(freq)
                if confirmed and confirmed[2]==mode:
                    print("F",freq,confirmed[0],mode,flush=True)
                    try:
                        recent_file.parent.mkdir(parents=True,exist_ok=True)
                        old=recent_file.read_text().split() if recent_file.exists() else []
                        tmp=recent_file.with_suffix(f".{os.getpid()}.tmp")
                        tmp.write_text(" ".join(list(dict.fromkeys([str(freq)]+old))[:12]))
                        tmp.replace(recent_file)
                    except OSError:
                        pass
                    break
        print("P",index+2,total,flush=True)
