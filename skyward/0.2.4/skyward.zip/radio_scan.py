"""One libhackrf RX stream per verification pass."""
import ctypes as C
import threading

class Transfer(C.Structure):
    _fields_=[("device",C.c_void_p),("buffer",C.c_void_p),("length",C.c_int),("valid",C.c_int),("rx",C.c_void_p),("tx",C.c_void_p)]

class Receiver:
    def __init__(self):
        self.lib=C.CDLL("libhackrf.so.0")
        self.dev=C.c_void_p()
        self.lock=threading.Lock()
        self.done=threading.Event()
        self.needed=0
        self.callback=C.CFUNCTYPE(C.c_int,C.POINTER(Transfer))(self.receive)
        self.check(self.lib.hackrf_init())
        try:
            self.check(self.lib.hackrf_open(C.byref(self.dev)))
            for name,value in [("sample_rate",C.c_double(20e6)),("baseband_filter_bandwidth",15000000),("lna_gain",24),("vga_gain",24),("amp_enable",0),("antenna_enable",0)]:
                self.check(getattr(self.lib,"hackrf_set_"+name)(self.dev,value))
            self.check(self.lib.hackrf_start_rx(self.dev,self.callback,None))
        except BaseException:
            self.close()
            raise
    @staticmethod
    def check(code):
        if code: raise RuntimeError(f"HackRF {code}")
    def receive(self,ptr):
        with self.lock:
            if not self.needed:return 0
            block=ptr.contents
            skip=min(self.skip,block.valid)
            self.skip-=skip
            count=min(self.needed,block.valid-skip)
            if count:self.data.extend(C.string_at(block.buffer+skip,count))
            self.needed-=count
            if not self.needed:self.done.set()
        return 0
    def capture(self,hz):
        self.check(self.lib.hackrf_set_freq(self.dev,C.c_uint64(hz)))
        with self.lock:
            self.done.clear()
            self.data=bytearray()
            self.skip=2000000  # Allow 50 ms of settling and queued USB data.
            self.needed=2400000
        if not self.done.wait(3):raise TimeoutError("HackRF RX timeout")
        return bytes(self.data)
    def close(self):
        if self.dev:
            self.lib.hackrf_stop_rx(self.dev)
            self.lib.hackrf_close(self.dev)
        self.lib.hackrf_exit()
